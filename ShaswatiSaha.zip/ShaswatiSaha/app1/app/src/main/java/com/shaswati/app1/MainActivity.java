package com.shaswati.app1;
import android.content.Intent;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.squareup.picasso.Picasso;
import android.support.v7.app.ActionBarActivity;

import android.content.Context;

import android.support.v7.widget.Toolbar;

import org.json.JSONArray;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

public class MainActivity extends ActionBarActivity {

    private Toolbar toolbar;
    RequestParams params = new RequestParams();
    TextView name1,  location1,city,location2, email1, phone1;
    ImageView iv1;
    Context context;
    public static String username,  ulocation1, ucity, ulocation2, uemail1, uphone1, uthumb;
    public static int flag=0; //using for view control
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = (Toolbar) findViewById(R.id.tool_bar); // Attaching the layout to the toolbar object
        setSupportActionBar(toolbar);
        name1= (TextView) findViewById(R.id.name);
        location1 = (TextView) findViewById(R.id.street);
        city = (TextView) findViewById(R.id.city);
        location2 = (TextView) findViewById(R.id.state);
        email1 = (TextView) findViewById(R.id.email);
        phone1 = (TextView) findViewById(R.id.phone);
        iv1=(ImageView)findViewById(R.id.profile_image);
        if(flag==0) {
            Intent i = getIntent();
            username = i.getStringExtra("name");
            ulocation1 = i.getStringExtra("location1");
            ucity = i.getStringExtra("city");
            ulocation2 = i.getStringExtra("location2");
            uemail1 = i.getStringExtra("email");
            uphone1 = i.getStringExtra("phone");
            uthumb = i.getStringExtra("image");
        }
        view();

    }
    public void view(){

        name1.setText(username) ;
        location1.setText(ulocation1);
        city.setText(ucity);
        location2.setText(ulocation2);
        email1.setText(uemail1);
        phone1.setText(uphone1);

        Picasso.with(getApplicationContext()).load(uthumb).into(iv1);

    }

    private void loadData() {
        try {
            AsyncHttpClient client = new AsyncHttpClient();
            client.post("https://randomuser.me/api/",
                    new AsyncHttpResponseHandler() {


                        @Override
                        public void onStart() {
                        }

                        @Override
                        public void onSuccess(int statusCode, Header[] headers,
                                              byte[] response) {


                            try {


                                JSONObject jsonObj = new JSONObject(new String(response));
                                JSONArray jsonArray = jsonObj.getJSONArray("results");

                                for (int i = 0; i < jsonArray.length(); i++) {

                                    JSONObject c = jsonArray.getJSONObject(i);

                                    JSONObject dummy=c.getJSONObject("user");
                                    JSONObject dummy1=dummy.getJSONObject("name");
                                    username = dummy1.getString("first") + " " + dummy1.getString("last");
                                    JSONObject dummy2=dummy.getJSONObject("location");
                                    ulocation1 = "Street: "+ dummy2.getString("street");
                                    ucity ="City: "+ dummy2.getString("city");
                                    ulocation2= "State: "+ dummy2.getString("state") + ", "+ "Zip: "+ dummy2.getString("zip");
                                    uemail1 =dummy.getString("email");
                                    uphone1 = dummy.getString("phone");
                                    JSONObject dummy4=c.getJSONObject("user");
                                    JSONObject dummy3=dummy4.getJSONObject("picture");
                                    uthumb = dummy3.getString("thumbnail");
                                    view();

                                }


                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        }

                        @Override
                        public void onFailure(int statusCode, Header[] headers,
                                              byte[] errorResponse, Throwable e) {

                        }

                        @Override
                        public void onRetry(int retryNo) {


                        }

                    });
        } catch (Exception e) {

        }



    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_refresh) {
            flag=1;
            loadData();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
