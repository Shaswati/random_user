package com.shaswati.app1;

/**
 * Think, Code, Enjoy! :D
 */
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

public class SplashScreen extends Activity {

    // Splash screen timer
    private static int SPLASH_TIME_OUT = 3000;
    String name1,location1,city1,location2, email1, phone1, thumb;
    private void loadData() {
        try {
            AsyncHttpClient client = new AsyncHttpClient();
            client.post("https://randomuser.me/api/",
                    new AsyncHttpResponseHandler() {


                        @Override
                        public void onStart() {
                        }

                        @Override
                        public void onSuccess(int statusCode, Header[] headers,
                                              byte[] response) {


                            try {


                                JSONObject jsonObj = new JSONObject(new String(response));
                                JSONArray jsonArray = jsonObj.getJSONArray("results");

                                for (int i = 0; i < jsonArray.length(); i++) {

                                    JSONObject c = jsonArray.getJSONObject(i);

                                    JSONObject dummy=c.getJSONObject("user");
                                    JSONObject dummy1=dummy.getJSONObject("name");
                                    name1=dummy1.getString("first") +" " + dummy1.getString("last");

                                    JSONObject dummy2=dummy.getJSONObject("location");

                                    location1="Street: "+ dummy2.getString("street") ;
                                    city1="City: "+ dummy2.getString("city");
                                    location2="State: "+ dummy2.getString("state") + ", "+ "Zip: "+ dummy2.getString("zip");
                                    email1=dummy.getString("email");
                                    phone1=dummy.getString("phone");
                                    JSONObject dummy4=c.getJSONObject("user");
                                    JSONObject dummy3=dummy4.getJSONObject("picture");
                                    thumb=dummy3.getString("thumbnail");
                                }


                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        }

                        @Override
                        public void onFailure(int statusCode, Header[] headers,
                                              byte[] errorResponse, Throwable e) {
                            // called when response HTTP status is "4XX" (eg.
                            // 401, 403, 404)

                            //progress.dismiss();
                            //newtext.setText("first2");

                        }

                        @Override
                        public void onRetry(int retryNo) {
                            // called when request is retried

                        }

                    });
        } catch (Exception e) {

        }



    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        loadData();
        new Handler().postDelayed(new Runnable() {

            /*
             * Showing splash screen with a timer. This will be useful when you
             * want to show case your app logo / company
             */

            @Override
            public void run() {
                // This method will be executed once the timer is over
                // Start your app main activity

                Intent i = new Intent(SplashScreen.this, MainActivity.class);
                i.putExtra("name", name1);
                i.putExtra("location1", location1);
                i.putExtra("city", city1);
                i.putExtra("location2", location2);
                i.putExtra("email", email1);
                i.putExtra("phone", phone1);
                i.putExtra("image", thumb);
                startActivity(i);

                // close this activity
                finish();
            }
        }, SPLASH_TIME_OUT);
    }

}